import React from 'react'

export default function Slide4() {
  return (
    <section style={ padding: 24 }>
      <h1>Slide 4</h1>
      <p>Replace this placeholder with your component.</p>
      <div id="content-ready" />
    </section>
  )
}
