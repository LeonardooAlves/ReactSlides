import React from 'react'

export default function Slide7() {
  return (
    <section style={ padding: 24 }>
      <h1>Slide 7</h1>
      <p>Replace this placeholder with your component.</p>
      <div id="content-ready" />
    </section>
  )
}
