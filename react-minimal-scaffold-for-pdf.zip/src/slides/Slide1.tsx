import React from 'react'

export default function Slide1() {
  return (
    <section style={ padding: 24 }>
      <h1>Slide 1</h1>
      <p>Replace this placeholder with your component.</p>
      <div id="content-ready" />
    </section>
  )
}
