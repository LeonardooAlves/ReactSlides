import React from 'react'

export default function Slide6() {
  return (
    <section style={ padding: 24 }>
      <h1>Slide 6</h1>
      <p>Replace this placeholder with your component.</p>
      <div id="content-ready" />
    </section>
  )
}
